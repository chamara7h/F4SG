# fit model using gam()

# Plot the linear predictor


# Adding additional terms


# Controlling smoothness
# Bigger value = smoother


# "REML"


# Visualising



