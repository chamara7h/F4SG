# Load packages
library(mgcv)

# Load data
covid <- readr::read_csv(
  "https://raw.githubusercontent.com/nrennie/f4sg-gams/main/data/covid.csv"
)

# Subset data to look at just FRA


# Split data to train and test sets


# Plot the data


# Which other variables may be of interest?


# fit a linear model using gam()


