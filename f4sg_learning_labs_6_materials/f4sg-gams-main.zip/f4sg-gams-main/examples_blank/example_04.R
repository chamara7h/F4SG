# look at autocorrelation in residuals
# caution: in this example, data is not equally spaced!


# fit a `gamm()`

# add a correlation structure

