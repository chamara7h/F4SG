pkgs <- c(
  "mgcv", "readr", "ggplot2", "dplyr", "gratia"
)
install.packages(pkgs)
