# quarto-presentation-template
a template repo for an online presentation prepared using Quarto
