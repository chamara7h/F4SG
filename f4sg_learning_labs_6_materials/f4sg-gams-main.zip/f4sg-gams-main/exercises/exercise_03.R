# Model check


# Obtain fitted values
# Same as `glm` function in R


# Predictions for new data


# Model interpretation

