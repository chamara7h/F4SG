# Model comparison

# Model check


# k = 10 is the default
# it seems too small


# Obtain fitted values
# Same as `glm` function in R


# Predictions for new data


# Model interpretation
